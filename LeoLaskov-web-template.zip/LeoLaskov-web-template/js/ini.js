$(document).ready(function(){
    $("#mmenu").click(function(){
        $(".mobilemenu").toggle("fast");
    });
}); 